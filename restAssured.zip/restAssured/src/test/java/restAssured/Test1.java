package restAssured;

import io.restassured.response.Response;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

public class Test1
{
    @Test
    public void test() {
        given().baseUri("https://643089673adb1596515cac02.mockapi.io")
                .when().get("/api/v1/users")
                .then().log().ifError()
                .assertThat().statusCode(200);
    }

    @Test
    public void testextract () {
        String name = given().baseUri("https://643089673adb1596515cac02.mockapi.io")
                .when().get("/api/v1/users")
                .then().extract().response().path("[20].name");
        System.out.println(name);
    }

    @Test
    public void testbody() {
        given().baseUri("https://643089673adb1596515cac02.mockapi.io")
                .when().get("/api/v1/users")
                .then().assertThat().body("name",is(not(empty())))
                .assertThat().body("[20].name",is(equalTo("Omar Khaled")))
                .assertThat().body("createdAt",everyItem(startsWith("2023")));
    }



}
